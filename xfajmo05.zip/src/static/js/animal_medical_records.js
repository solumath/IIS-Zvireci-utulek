$( document ).ready(function() {
    console.log( "ready!" );

    $('.medicalRecordsTableFuture').DataTable();
    $('.medicalRecordsTableHistory').DataTable();
});
