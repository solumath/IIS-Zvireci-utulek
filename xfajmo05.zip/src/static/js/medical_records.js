$( document ).ready(function() {
    console.log( "ready!" );

    $('.medicalRecords').DataTable();
    $('.requestExaminations').DataTable();
});
