$( document ).ready(function() {
    console.log( "ready!" );

    $('#futureTable').DataTable();
    $('#historyTable').DataTable();
});
