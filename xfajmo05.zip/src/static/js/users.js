$( document ).ready(function() {
    console.log( "ready!" );

    $('.usersTableAdmin').DataTable();
    $('.usersTableCaretaker').DataTable();
});
